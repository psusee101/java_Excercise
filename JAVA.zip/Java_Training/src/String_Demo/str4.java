package String_Demo;

public class str4 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		String s1="Sachin";
		String s2="Sachin";
		String s3="Tendulkar";
		
		System.out.println(s1.compareTo(s2)); //0
		System.out.println(s1.compareTo(s3)); //-1
		

	}

}
