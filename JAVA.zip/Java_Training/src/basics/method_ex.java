package basics;

public class method_ex 
{
	int add()
	{
		int a,b;
		
		a=56;
		b=98;
		int c=a+b;
		
		return c;
	}
	
	void sum()
	{
		int a,b;
		
		a=56;
		b=98;
		int c=a+b;
		
		System.out.println("result is:"+ c);
	}
	
	float sub(float x,float y)
	{
		return x-y;
		
	}

	public static void main(String args[])
	{
	method_ex obj  = new method_ex();
	
	System.out.println(obj.add());
	System.out.println(obj.add());
	System.out.println(obj.add());
	System.out.println(obj.add());
	obj.sum();
	System.out.println(obj.sub(89,5));
	System.out.println(obj.sub(90,5));
	System.out.println(obj.sub(43,5));
	System.out.println(obj.sub(54,5));
	System.out.println(obj.sub(33,5));
	
	}

}
