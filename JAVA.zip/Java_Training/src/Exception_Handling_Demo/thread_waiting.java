package Exception_Handling_Demo;

public class thread_waiting implements Runnable {
	public static Thread t1;

	public static void main(String[] args) {
		t1=new Thread();
		t1.start();

	}

	@Override
	public void run() {
		
		Thread t2 =new Thread(new threadDemo());
		t2.start();
		
		try {
			t2.join();
		}catch(Exception e)
		{
			Thread.currentThread().interrupt();
			System.out.println(e);
		}
	}

}


class threadDemo implements Runnable{
	public void run()
	{
		try {
			Thread.sleep(1000);
		}catch(Exception e)
		{
			Thread.currentThread().interrupt();
			System.out.println(e);

		}
		System.out.println(t1.getState());

	}
}
