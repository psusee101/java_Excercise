package basics;

class parent3
{
	void show()
	{
		System.out.println("from parent class");
	}
}
class child3 extends parent3
{
	void show()
	{
	
		System.out.println("from child class");
		
	}
}

public class method_override {

	public static void main(String[] args)
	{

	child3 c =new child3();
	c.show();

	}

}
