package basics;

import java.util.Scanner;

public class armstrong_num 
{
  public void arm_strong(int num)
	{
		int temp,total=0,number;
		number=num;
		
		while(num!=0) //
		{
			temp=num%10; // 3 5 1
			total+=temp*temp*temp; //27 +125 +1
			num=num/10; // 0
		}
		
		if(number==total)
		{
			System.out.println(number +":Given number is ArmStrong number");
		}
		
		else
		{
			System.out.println(number +":Given number is not an ArmStrong number");
		}
		
	}

	

}
