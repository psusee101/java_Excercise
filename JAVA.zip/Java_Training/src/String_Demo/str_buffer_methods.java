package String_Demo;

public class str_buffer_methods {

	public static void main(String[] args) 
	{
		StringBuffer s= new StringBuffer("Hello World");
		StringBuffer s1= new StringBuffer("Hello");
		s.append(" Java");
		System.out.println(s);// hello world java
		s.insert(1,"Java"); //Hjavaello world
		System.out.println(s);
		s.replace(1, 3, "Buffer");
		System.out.println(s);
		s.delete(1, 3);
		System.out.println(s);
		s.reverse();
		System.out.println(s);
		System.out.println(s1.capacity());
		s1.append("java string is my favourite topic in core java");
		System.out.println(s1.capacity());

		
	}

}
