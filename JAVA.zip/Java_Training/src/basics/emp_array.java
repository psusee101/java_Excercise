package basics;
import java.util.Scanner;

public class emp_array
{
public static void main(String args[])
{
	int nos;
	Scanner s =new Scanner(System.in);
	
	System.out.println("Enter the no of employees");
	nos=s.nextInt();
	
	int emp_no[] =new int[nos];
	String name[] =new String[nos];
	Float[] salary =new Float[nos];
	
	System.out.println("Enter the Employee Number");
	for(int i=0;i<emp_no.length;i++)
	{
		emp_no[i]=s.nextInt();
	}
	
	System.out.println("Enter the Employee Name");
	for(int i=0;i<name.length;i++)
	{
		name[i]=s.next();
	}
	
	System.out.println("Enter the Employee Salary");
	for(int i=0;i<salary.length;i++)
	{
		salary[i]=s.nextFloat();
	
	}
	
	System.out.println("Entered Employee Details are:");
	for(int i:emp_no)
	{
		System.out.println("Employee Number:"+i);
	}
	
	for(String s1:name)
	{
		System.out.println("Employee Name:"+s1);
	}
	
	for(float f:salary)
	{
		System.out.println("Employee salary:"+f);
	
	}
	
	
}
}
