package Exception_Handling_Demo;

public class demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello World befor exception");
		try
		{
		int x=10/0;
		}catch(ArithmeticException o)
		{
			System.out.println(o);
		}
		System.out.println("After the exception");
		System.out.println("executed successfully");

		
	}

}
