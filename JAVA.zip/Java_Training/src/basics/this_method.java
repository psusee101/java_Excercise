package basics;

class A1
{
	void m()
	{
		System.out.println("Hello M");
		
	}
	
	void n()
	{
		System.out.println("Hello N");
		this.m();
		
	}
}
public class this_method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A1 obj =new A1();
		obj.n();

	}

}
