package DS;

import java.util.*;

public class Array_list {

	public static void main(String[] args) {
		
		ArrayList list =new ArrayList();
		
		list.add(101);
		list.add("Books");
		list.add(1999.00);
		list.add(101);
		list.add("Books");
		list.add(1999.00);
		
		System.out.println(list);
		
		System.out.println("5th element"+list.get(5));
		list.set(4, "Fruits");
		System.out.println(list);


		Iterator itr= list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());

		}
		
		ArrayList<String> al =new ArrayList<String>();
		
		al.add("Mango");
		al.add("Orange");
		al.add("Graph");
		al.add("Apple");
		al.add("Kiwi");
		
		Collections.sort(al);
		
		System.out.println(al);

		
		for(String s : al)
		{
			System.out.println(s);
		}

	}

}
