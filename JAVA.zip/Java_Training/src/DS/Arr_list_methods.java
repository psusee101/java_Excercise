package DS;

import java.util.*;
public class Arr_list_methods {

	public static void main(String[] args)
	{
		ArrayList al =new ArrayList();
		
		System.out.println("is Array List is Empty:"+al.isEmpty());
		System.out.println(" Array List size:"+al.size());
		al.add("Ravi");
		al.add("Vijay");
		al.add("Ajay");
		
		System.out.println("After Add method:"+al);
		System.out.println("is Array List is Empty:"+al.isEmpty());
		
		al.add(1,"Gaurav");
		System.out.println("After Adding 1st index :"+al);
		
		ArrayList al2=new ArrayList();
		al2.add("sonoo");
		al2.add("Hanumath");
		
		al.addAll(al2);
		System.out.println("After Adding 1st index :"+al);
		
		ArrayList al3=new ArrayList();
		al3.add("Rahul");
		al3.add("John");
		
		al.addAll(1,al3);
		
		System.out.println("After Adding  :"+al);

		System.out.println(" Array List size:"+al.size());
		
		Collections.sort(al);
		System.out.println(" Ascending Order:"+al);
		
		Collections.sort(al,Collections.reverseOrder());
		System.out.println(" Decending Order:"+al);

		
		
	}

}
