package basics;

public class while_ex
{
	public static void main(String args[])
	{
		int i=0,n=10;
		
		while(i<n)
		{
			System.out.println("Hello World"+i);i++;
		}
	}

}
