package basics;
import java.util.Scanner;

class stu
{
	int regno,m1,m2,m3,tot,avg;
	String name,result;
	
	void read_details()
	{
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the Regno");
		regno=s.nextInt();

		System.out.println("Enter the Name");
		name=s.next();
		
		System.out.println("Enter the Mark1");
		m1=s.nextInt();
		
		System.out.println("Enter the Mark2");
		m2=s.nextInt();
		
		System.out.println("Enter thevMark3");
		m3=s.nextInt();
	}
	
	void marksheet()
	{
		tot=m1+m2+m3;
		avg=tot/3;
		if(m1>=50 && m2>=50 && m3>=50)
		{
			result="pass";
		}
		else
			
		{
			result="fail";
		}
	}
	void display()
	{
		System.out.println("Student Details");
		System.out.println("Student Reg No:"+regno);
		System.out.println("Student Name:"+name);
		System.out.println("S Mark1:"+m1);
		System.out.println(" Mark2:"+m2);
		System.out.println(" Mark3:"+m3);
		System.out.println(" Total:"+regno);
		System.out.println("Average:"+avg);
		System.out.println("Result"+result);
	}
}



public class student {
	

	public static void main(String[] args) 
	{
	stu s =new stu();
	s.regno=1011;
	System.out.println("Reg no:"+s.regno);
	s.name="sachin";
	System.out.println("name:"+s.name);

	s.read_details();
	s.marksheet();
	s.display();

	}

}
