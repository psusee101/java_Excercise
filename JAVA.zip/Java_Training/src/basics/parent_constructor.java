package basics;

class parent1
{
	parent1()
	{
		System.out.println("Parent class costructor");
	}
}

class child1 extends parent1
{
	child1()
	{
		super();
		
		System.out.println("Child class costructor");

		
	}
}
public class parent_constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child1 c =new child1();
	}

}
