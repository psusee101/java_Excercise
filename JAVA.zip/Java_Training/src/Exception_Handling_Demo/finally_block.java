package Exception_Handling_Demo;

public class finally_block {

	public static void main(String[] args)
	{
		try
		{
			int a[]=new int[5];
			
			a[12]=89;
			System.out.println(a[12]);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally {
			System.out.println("Finally block always execute at last");

		}
		
		System.out.println("Rest of the code");	

	}

}
