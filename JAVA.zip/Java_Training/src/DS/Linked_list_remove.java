package DS;

import java.util.*;

public class Linked_list_remove {

	public static void main(String[] args) {
		
LinkedList al =new LinkedList();
		
		
		al.add("Ravi");
		al.add("Vijay");
		al.add("Ajay");

		al.add("Anuj");
		al.add("Gaurav");
		al.add("Harsh");
		
		al.add("Virat");
		al.add("Gaurav");
		al.add("Harsh");
		al.add("Amit");
		
		System.out.println("Inital Linked List:"+al);
		
		al.remove("Vijay");
		
		System.out.println("Inital Linked List:"+al);

		al.remove(0);
		
		System.out.println("Inital Linked List:"+al);
		
		
		LinkedList<String> ll2 =new LinkedList<String>();
			ll2.add("Ravi");
			ll2.add("Hanumanth");
			al.addAll(ll2);
			
			System.out.println("Updated Linked List:"+al);
			
			al.removeFirst();
			System.out.println("after removing first element Linked List:"+al);

			al.removeLast();
			System.out.println("after removing last element Linked List:"+al);

			al.removeFirstOccurrence("Gaurav");
			System.out.println("after removing last element Linked List:"+al);
			
			al.removeLastOccurrence("Harsh");
			System.out.println("after removing last element Linked List:"+al);
			
			Iterator i =al.descendingIterator();
			
			while(i.hasNext())
			{
				System.out.println(i.next());
			}
			


	}

}
