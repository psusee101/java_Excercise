package String_Demo;

public class string_new_keyword {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		String s1 =new String("Hello Java");
		String s2 =new String(" Java String");
		char name[]= {'r','o','h','i','t','h'};
		String s3 =new String(name);
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);

	}

}
