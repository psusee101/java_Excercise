package Exception_Handling_Demo;

public class String_index {

	public static void main(String[] args) {
		
		String str="welcome to java exception handling";
		try {
		System.out.println("length:"+str.length());
		System.out.println("length:"+str.substring(40));
		}catch(StringIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		System.out.println("Rest of the code");

	}

}
