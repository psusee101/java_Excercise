package Multi_thread_Demo;

class multi_thread extends Thread
{
	public void run()
	{
		System.out.println("thread is running");
	}
	
}
public class demo_thread {

	public static void main(String[] args)
	{
	
		multi_thread m =new multi_thread();
		
		m.start();

	}

}
