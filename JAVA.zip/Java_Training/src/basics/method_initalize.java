package basics;

 class customer123 {
	int id;
	String name,address;
 
	void data_initalize(int id,String name,String address)
	{
		this.id=id;
		this.name=name;
		this.address=address;
	}
	void display()
	{
		System.out.println("Customer ID:"+id);
		System.out.println("Customer name:"+name);
		System.out.println("Customer Address:"+address);
	}
}

public class method_initalize {

	public static void main(String[] args) {
		customer123 obj =new customer123();
		
		obj.data_initalize(111, "Thoni", "Mumbai");
		obj.display();
		
		obj.data_initalize(102,"Anu","Bangalore");
		obj.display();

	}

}
