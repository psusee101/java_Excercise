package Exception_Handling_Demo;

public class throw_ex 
{
	public static void validate(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("Person is not eligible for vote");
		}
		else
		{
			System.out.println("Person is eligible for vote");
		}
	}

	public static void main(String[] args) 
	{

		validate(27);
		System.out.println("Rest of the code executed successfully!");
	}

}
