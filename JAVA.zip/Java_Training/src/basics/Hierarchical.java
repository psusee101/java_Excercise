package basics;

import java.util.Scanner;

 class Parent
{
	String name,pname,address,acc_type;
	int id,pid,price,acc_no,balance_amt;
	
	protected void accounts_data()
	{
		Scanner s  =new Scanner(System.in);
		
		System.out.println("Enter the Account Number");
		acc_no=s.nextInt();
		System.out.println("Enter the Account Type");
		acc_type=s.next();
		
		System.out.println("Enter the Account Balance ");
		balance_amt=s.nextInt();
		
	}
	
	
	void product_data()
	{
		Scanner s  =new Scanner(System.in);
		
		System.out.println("Enter the Product Id");
		pid=s.nextInt();
		System.out.println("Enter the Product Name");
		pname=s.next();
		
		System.out.println("Enter the Product Price");
		price=s.nextInt();
		
	}
	

	void customer_data()
	{
		Scanner s  =new Scanner(System.in);
		
		System.out.println("Enter the Customer Id");
		id=s.nextInt();
		System.out.println("Enter the Customer Name");
		name=s.next();
		
		System.out.println("Enter the Customer Address");
		address=s.next();
		
	}
	
	}

class cus_child extends Parent
{
		void cus_report()
	{
		System.out.println(" Customer Id:"+id);
		System.out.println(" Customer Name:"+name);
		System.out.println(" Customer Address:"+address);

	}
}

class product_child extends Parent
{
	void pro_report()
	{
		System.out.println(" Product Id:"+id);
		System.out.println(" Product Name:"+name);
		System.out.println(" Product Price:"+price);

	}

}

class Acc_child extends Parent
{
	void accounts_report()
{
	System.out.println(" Account Number:"+acc_no);
	System.out.println(" Account Type:"+acc_type);
	System.out.println(" Account Balance:"+balance_amt);

}
	
	}


public class Hierarchical {

	public static void main(String[] args)
	{
		cus_child cobj =new cus_child();
		
		cobj.customer_data();
		cobj.cus_report();
		
		Acc_child aobj =new Acc_child();
		
		aobj.accounts_data();
		aobj.accounts_report();
		
		
		product_child pobj =new product_child();
		
		pobj.product_data();
		pobj.pro_report();
		
		Parent p =new Parent();
		
		p.accounts_data();

	}

}
