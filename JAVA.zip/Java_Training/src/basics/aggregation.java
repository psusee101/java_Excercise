package basics;

class Address
{
	String city,state,country;
	
	public Address(String city,String state,String country)
	{
		this.city=city;
		this.state=state;
		this.country=country;
	}
}
class Emp  
{
	int empid;
	String name;
	Address add; // entity relationship
	
	public Emp(int empid,String name,Address add)
	{
		this.empid=empid;
		this.name=name;
		this.add=add;
	}
	
	void display()
	{
		System.out.println(empid+" "+name);
		System.out.println(add.city+" "+add.state+" "+add.country);
	}
}

public class aggregation {

	public static void main(String[] args) {
		Address add1 =new Address("chennai","TamilNadu","India");
		Address add2 =new Address("Bangalore","Karnataka","India");
		
		Emp e =new Emp(111,"Sachin",add1);
		Emp e1 =new Emp(112,"thoni",add2);
		
		e.display();
		e1.display();
		

	}

}
